import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/common/Layout';
import HomePage from './pages/HomePage';
import MoviePage from './pages/MoviePage';
import SearchPage from './pages/SearchPage';
import GenrePage from './pages/GenrePage';
import LanguagePage from './pages/LanguagePage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout transparentNavbar />}>
          <Route index element={<HomePage />} />
        </Route>
        <Route path="/" element={<Layout />}>
          <Route path="movie/:id" element={<MoviePage />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="genre/:genre" element={<GenrePage />} />
          <Route path="language/:language" element={<LanguagePage />} />
          {/* Add more routes as needed */}
        </Route>
      </Routes>
    </Router>
  );
}

export default App;