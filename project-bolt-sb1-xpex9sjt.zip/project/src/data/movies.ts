import { Movie, MovieLanguage, MovieGenre } from '../types/movie';

export const movies: Movie[] = [
  {
    id: '1',
    title: 'The Lost Kingdom',
    description: 'An epic adventure where a young warrior must reclaim her homeland from dark forces that have overtaken the once peaceful kingdom.',
    posterUrl: 'https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/2873486/pexels-photo-2873486.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023,
    duration: '2h 15m',
    language: 'English',
    genres: ['Action', 'Adventure', 'Fantasy'],
    rating: 8.5,
    cast: [
      {
        name: 'Emma Stone',
        role: 'Princess Lyra',
        imageUrl: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Michael B. Jordan',
        role: 'Commander Kael',
        imageUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Christopher Nolan',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isFeatured: true,
    isTrending: true
  },
  {
    id: '2',
    title: 'Midnight Mysteries',
    description: 'A detective with a troubled past must solve a series of cryptic murders that all seem to point to an ancient cult.',
    posterUrl: 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/3075993/pexels-photo-3075993.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023,
    duration: '1h 58m',
    language: 'English',
    genres: ['Mystery', 'Thriller', 'Drama'],
    rating: 7.9,
    cast: [
      {
        name: 'Idris Elba',
        role: 'Detective Marcus Wells',
        imageUrl: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Ana de Armas',
        role: 'Dr. Sophia Chen',
        imageUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'David Fincher',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isTrending: true
  },
  {
    id: '3',
    title: 'Whispers of the Heart',
    description: 'A touching romantic drama about two childhood friends who reconnect after years apart, only to discover their feelings run deeper than friendship.',
    posterUrl: 'https://images.pexels.com/photos/5792641/pexels-photo-5792641.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022,
    duration: '2h 05m',
    language: 'Hindi',
    genres: ['Romance', 'Drama'],
    rating: 8.2,
    cast: [
      {
        name: 'Ranbir Kapoor',
        role: 'Vikram Shah',
        imageUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Alia Bhatt',
        role: 'Meera Patel',
        imageUrl: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Karan Johar',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isFeatured: true
  },
  {
    id: '4',
    title: 'Digital Dreams',
    description: 'In a near-future world where virtual reality has replaced real life for most people, one programmer discovers a deadly glitch in the system.',
    posterUrl: 'https://images.pexels.com/photos/3227986/pexels-photo-3227986.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023,
    duration: '2h 20m',
    language: 'English',
    genres: ['Sci-Fi', 'Thriller', 'Action'],
    rating: 8.7,
    cast: [
      {
        name: 'John Boyega',
        role: 'Ethan Wright',
        imageUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Zendaya',
        role: 'Nova Jones',
        imageUrl: 'https://images.pexels.com/photos/1898555/pexels-photo-1898555.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Denis Villeneuve',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isTrending: true
  },
  {
    id: '5',
    title: 'The Last Dance',
    description: 'A celebrated ballet dancer faces her greatest challenge when an injury threatens to end her career just before her final performance.',
    posterUrl: 'https://images.pexels.com/photos/6664250/pexels-photo-6664250.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/358010/pexels-photo-358010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022,
    duration: '1h 52m',
    language: 'French',
    genres: ['Drama'],
    rating: 7.8,
    cast: [
      {
        name: 'Léa Seydoux',
        role: 'Camille Laurent',
        imageUrl: 'https://images.pexels.com/photos/1642228/pexels-photo-1642228.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Vincent Cassel',
        role: 'Director Antoine',
        imageUrl: 'https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'François Ozon',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isFeatured: true
  },
  {
    id: '6',
    title: 'Rooftop Melodies',
    description: 'In the bustling streets of Dhaka, a young street musician and a privileged college student form an unlikely musical partnership.',
    posterUrl: 'https://images.pexels.com/photos/7577331/pexels-photo-7577331.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022,
    duration: '2h 10m',
    language: 'Bengali',
    genres: ['Drama', 'Romance', 'Music'],
    rating: 8.0,
    cast: [
      {
        name: 'Chanchal Chowdhury',
        role: 'Rahim',
        imageUrl: 'https://images.pexels.com/photos/775358/pexels-photo-775358.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Jaya Ahsan',
        role: 'Priya',
        imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Mostofa Sarwar Farooki',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '7',
    title: 'Escape Plan',
    description: 'A brilliant thief assembles a team of specialists for one last heist that will set them all up for life, if they can trust each other.',
    posterUrl: 'https://images.pexels.com/photos/2833037/pexels-photo-2833037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/1619317/pexels-photo-1619317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023,
    duration: '2h 08m',
    language: 'English',
    genres: ['Action', 'Crime', 'Thriller'],
    rating: 7.6,
    cast: [
      {
        name: 'Tom Hardy',
        role: 'Jack Reynolds',
        imageUrl: 'https://images.pexels.com/photos/1121796/pexels-photo-1121796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Lupita Nyong\'o',
        role: 'Maya Davis',
        imageUrl: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Guy Ritchie',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isTrending: true
  },
  {
    id: '8',
    title: 'Cherry Blossoms',
    description: 'An elderly American professor travels to Japan to understand the culture his late wife cherished, finding unexpected connections along the way.',
    posterUrl: 'https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    backdropUrl: 'https://images.pexels.com/photos/1031781/pexels-photo-1031781.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2021,
    duration: '1h 55m',
    language: 'Japanese',
    genres: ['Drama', 'Romance'],
    rating: 8.4,
    cast: [
      {
        name: 'Ken Watanabe',
        role: 'Takashi',
        imageUrl: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      },
      {
        name: 'Meryl Streep',
        role: 'Eleanor',
        imageUrl: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
      }
    ],
    director: 'Hirokazu Kore-eda',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];

export const getMoviesByLanguage = (language: MovieLanguage) => 
  movies.filter(movie => movie.language === language);

export const getMoviesByGenre = (genre: MovieGenre) => 
  movies.filter(movie => movie.genres.includes(genre));

export const getFeaturedMovies = () => 
  movies.filter(movie => movie.isFeatured);

export const getTrendingMovies = () => 
  movies.filter(movie => movie.isTrending);

export const searchMovies = (query: string) => 
  movies.filter(movie => 
    movie.title.toLowerCase().includes(query.toLowerCase()) ||
    movie.cast.some(actor => actor.name.toLowerCase().includes(query.toLowerCase())) ||
    movie.director.toLowerCase().includes(query.toLowerCase())
  );

export const getMovieById = (id: string) => 
  movies.find(movie => movie.id === id);

export const getRelatedMovies = (movie: Movie) => 
  movies
    .filter(m => 
      m.id !== movie.id && 
      (m.genres.some(genre => movie.genres.includes(genre)) || 
       m.language === movie.language)
    )
    .slice(0, 4);