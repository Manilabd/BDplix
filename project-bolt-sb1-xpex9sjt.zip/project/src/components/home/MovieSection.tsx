import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MovieCard from '../movie/MovieCard';
import { Movie } from '../../types/movie';

interface MovieSectionProps {
  title: string;
  movies: Movie[];
  viewAllLink?: string;
  variant?: 'default' | 'featured' | 'compact';
}

const MovieSection: React.FC<MovieSectionProps> = ({ 
  title, 
  movies, 
  viewAllLink,
  variant = 'default'
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-2xl font-bold">{title}</h2>
          {viewAllLink && (
            <Link to={viewAllLink} className="text-red-500 hover:text-red-400 font-medium transition-colors">
              View All
            </Link>
          )}
        </div>

        <div className="relative group">
          {/* Scroll Buttons */}
          <button 
            onClick={scrollLeft}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 z-10 bg-black/80 hover:bg-black text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity -ml-4"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button 
            onClick={scrollRight}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 z-10 bg-black/80 hover:bg-black text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity -mr-4"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Movie Slider */}
          <div 
            ref={sliderRef}
            className="flex space-x-4 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {variant === 'featured' ? (
              movies.slice(0, 3).map(movie => (
                <div key={movie.id} className="flex-none w-full md:w-[85%] lg:w-[60%]">
                  <MovieCard movie={movie} variant="featured" />
                </div>
              ))
            ) : (
              movies.map(movie => (
                <div 
                  key={movie.id} 
                  className={`flex-none ${
                    variant === 'compact' 
                      ? 'w-28 md:w-32 lg:w-40' 
                      : 'w-40 sm:w-48 md:w-56 lg:w-64'
                  }`}
                >
                  <MovieCard movie={movie} variant={variant} />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MovieSection;