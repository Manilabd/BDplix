import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, Plus } from 'lucide-react';
import { Movie } from '../../types/movie';

interface HeroSectionProps {
  movies: Movie[];
}

const HeroSection: React.FC<HeroSectionProps> = ({ movies }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isChanging, setIsChanging] = useState(false);
  const currentMovie = movies[currentIndex];

  useEffect(() => {
    const interval = setInterval(() => {
      setIsChanging(true);
      setTimeout(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % movies.length);
        setIsChanging(false);
      }, 500);
    }, 8000);

    return () => clearInterval(interval);
  }, [movies.length]);

  return (
    <div className="relative w-full h-[85vh] overflow-hidden">
      {/* Background Image */}
      <div 
        className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ${isChanging ? 'opacity-0' : 'opacity-100'}`}
        style={{ backgroundImage: `url(${currentMovie.backdropUrl})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative h-full flex flex-col justify-end pb-16 md:pb-24">
        <div className={`max-w-2xl transition-all duration-700 ${isChanging ? 'opacity-0 translate-y-8' : 'opacity-100 translate-y-0'}`}>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">{currentMovie.title}</h1>
          <div className="flex items-center space-x-4 mb-4">
            <span className="bg-red-600 text-white px-2 py-1 rounded text-sm font-medium">{currentMovie.rating.toFixed(1)}</span>
            <span className="text-gray-300">{currentMovie.year}</span>
            <span className="text-gray-300">{currentMovie.duration}</span>
            <span className="text-gray-300">{currentMovie.language}</span>
          </div>
          <p className="text-gray-300 mb-8 text-lg line-clamp-3">
            {currentMovie.description}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link 
              to={`/movie/${currentMovie.id}`} 
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-md font-medium flex items-center transition-colors"
            >
              <Play className="w-5 h-5 mr-2" />
              Watch Now
            </Link>
            <button className="bg-gray-800/80 hover:bg-gray-700 text-white px-6 py-3 rounded-md font-medium flex items-center transition-colors">
              <Plus className="w-5 h-5 mr-2" />
              Add to Watchlist
            </button>
          </div>
        </div>

        {/* Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {movies.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setIsChanging(true);
                setTimeout(() => {
                  setCurrentIndex(index);
                  setIsChanging(false);
                }, 500);
              }}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentIndex ? 'bg-red-600 w-8' : 'bg-gray-500 hover:bg-gray-400'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroSection;