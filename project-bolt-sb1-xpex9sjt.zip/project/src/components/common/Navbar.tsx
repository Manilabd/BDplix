import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Film, Menu, X, ChevronDown, LogIn, Heart } from 'lucide-react';
import { MovieLanguage } from '../../types/movie';

interface NavbarProps {
  transparent?: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ transparent = false }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const languages: MovieLanguage[] = ['English', 'Hindi', 'Bengali', 'Spanish', 'Korean', 'Japanese', 'French'];
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navbarClasses = `
    fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4
    ${isScrolled || !transparent ? 'bg-gray-900/95 backdrop-blur-md shadow-lg' : 'bg-gradient-to-b from-black/80 to-transparent'}
  `;

  return (
    <header className={navbarClasses}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <Film className="w-8 h-8 text-red-600 mr-2" />
          <span className="text-white font-bold text-2xl">BDPlix</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-white hover:text-red-500 font-medium transition-colors">
            Home
          </Link>
          <div className="relative group">
            <button className="text-white hover:text-red-500 font-medium transition-colors flex items-center">
              Categories <ChevronDown className="ml-1 w-4 h-4" />
            </button>
            <div className="absolute left-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              <Link to="/genre/action" className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700">Action</Link>
              <Link to="/genre/comedy" className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700">Comedy</Link>
              <Link to="/genre/drama" className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700">Drama</Link>
              <Link to="/genre/thriller" className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700">Thriller</Link>
              <Link to="/genre/romance" className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700">Romance</Link>
            </div>
          </div>
          <div className="relative group">
            <button className="text-white hover:text-red-500 font-medium transition-colors flex items-center">
              Languages <ChevronDown className="ml-1 w-4 h-4" />
            </button>
            <div className="absolute left-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              {languages.map(language => (
                <Link 
                  key={language} 
                  to={`/language/${language.toLowerCase()}`} 
                  className="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700"
                >
                  {language}
                </Link>
              ))}
            </div>
          </div>
          <Link to="/trending" className="text-white hover:text-red-500 font-medium transition-colors">
            Trending
          </Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="text-white hover:text-red-500 transition-colors p-1"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>
          <Link to="/watchlist" className="hidden md:block text-white hover:text-red-500 transition-colors p-1">
            <Heart className="w-5 h-5" />
          </Link>
          <Link to="/login" className="hidden md:flex items-center text-white bg-red-600 hover:bg-red-700 px-4 py-2 rounded-md transition-colors">
            <LogIn className="w-4 h-4 mr-2" />
            <span>Sign In</span>
          </Link>
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white hover:text-red-500 transition-colors p-1"
            aria-label="Menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Search Overlay */}
      {isSearchOpen && (
        <div className="absolute top-full left-0 right-0 bg-gray-900/95 backdrop-blur-md p-4 shadow-lg">
          <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for movies, actors, directors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-800 text-white rounded-full py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </form>
        </div>
      )}

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-gray-900/95 z-50 md:hidden">
          <div className="container mx-auto px-4 py-6">
            <div className="flex justify-between items-center mb-8">
              <Link to="/" className="flex items-center" onClick={() => setIsMenuOpen(false)}>
                <Film className="w-8 h-8 text-red-600 mr-2" />
                <span className="text-white font-bold text-2xl">BDPlix</span>
              </Link>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="text-white hover:text-red-500 transition-colors p-1"
                aria-label="Close menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="flex flex-col space-y-6">
              <Link 
                to="/" 
                className="text-white text-xl font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <div className="space-y-4">
                <h3 className="text-gray-400 text-lg">Categories</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Link 
                    to="/genre/action" 
                    className="text-white text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Action
                  </Link>
                  <Link 
                    to="/genre/comedy" 
                    className="text-white text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Comedy
                  </Link>
                  <Link 
                    to="/genre/drama" 
                    className="text-white text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Drama
                  </Link>
                  <Link 
                    to="/genre/thriller" 
                    className="text-white text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Thriller
                  </Link>
                  <Link 
                    to="/genre/romance" 
                    className="text-white text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Romance
                  </Link>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-gray-400 text-lg">Languages</h3>
                <div className="grid grid-cols-2 gap-4">
                  {languages.map(language => (
                    <Link 
                      key={language}
                      to={`/language/${language.toLowerCase()}`} 
                      className="text-white text-lg"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {language}
                    </Link>
                  ))}
                </div>
              </div>
              <Link 
                to="/trending" 
                className="text-white text-xl font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Trending
              </Link>
              <Link 
                to="/watchlist" 
                className="text-white text-xl font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                My Watchlist
              </Link>
              <Link 
                to="/login" 
                className="text-white bg-red-600 hover:bg-red-700 py-3 rounded-md transition-colors text-center text-xl font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Sign In
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;