import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, Heart, Star, Calendar, Clock, Languages } from 'lucide-react';
import { Movie } from '../../types/movie';
import MovieSection from '../home/MovieSection';
import { getRelatedMovies } from '../../data/movies';

interface MovieDetailsProps {
  movie: Movie;
}

const MovieDetails: React.FC<MovieDetailsProps> = ({ movie }) => {
  const [isInWatchlist, setIsInWatchlist] = useState(false);
  const relatedMovies = getRelatedMovies(movie);

  const toggleWatchlist = () => {
    setIsInWatchlist(!isInWatchlist);
    // In a real app, you would update this in a database or local storage
  };

  return (
    <>
      {/* Hero Section */}
      <div className="relative">
        {/* Backdrop Image */}
        <div className="w-full h-[50vh] md:h-[70vh] relative">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${movie.backdropUrl})` }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/80 to-black/60" />
          </div>
          
          {/* Play Trailer Button (centered) */}
          <div className="absolute inset-0 flex items-center justify-center">
            <a 
              href={movie.trailerUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-16 h-16 md:w-20 md:h-20 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center transition-transform duration-300 transform hover:scale-110"
              aria-label="Play trailer"
            >
              <Play className="w-8 h-8 md:w-10 md:h-10" />
            </a>
          </div>
        </div>

        {/* Movie Info Section */}
        <div className="container mx-auto px-4 relative -mt-40 md:-mt-48 z-10 pb-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Poster */}
            <div className="w-48 md:w-64 mx-auto md:mx-0 rounded-lg overflow-hidden shadow-2xl">
              <img 
                src={movie.posterUrl} 
                alt={movie.title} 
                className="w-full h-auto"
              />
            </div>
            
            {/* Details */}
            <div className="flex-1">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">{movie.title}</h1>
              
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <span className="bg-red-600 text-white px-2 py-1 rounded text-sm font-medium flex items-center">
                  <Star className="w-4 h-4 mr-1 fill-current" />
                  {movie.rating.toFixed(1)}
                </span>
                <span className="flex items-center text-gray-300">
                  <Calendar className="w-4 h-4 mr-2" />
                  {movie.year}
                </span>
                <span className="flex items-center text-gray-300">
                  <Clock className="w-4 h-4 mr-2" />
                  {movie.duration}
                </span>
                <span className="flex items-center text-gray-300">
                  <Languages className="w-4 h-4 mr-2" />
                  {movie.language}
                </span>
              </div>
              
              <div className="mb-6">
                <div className="flex flex-wrap gap-2 mb-4">
                  {movie.genres.map(genre => (
                    <Link 
                      key={genre} 
                      to={`/genre/${genre.toLowerCase()}`}
                      className="bg-gray-800 hover:bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm transition-colors"
                    >
                      {genre}
                    </Link>
                  ))}
                </div>
                <p className="text-gray-300 text-lg leading-relaxed">
                  {movie.description}
                </p>
              </div>
              
              <div className="flex flex-wrap gap-4 mb-8">
                <button 
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-md font-medium flex items-center transition-colors"
                  onClick={() => window.open(movie.trailerUrl, '_blank')}
                >
                  <Play className="w-5 h-5 mr-2" />
                  Watch Trailer
                </button>
                <button 
                  className={`${
                    isInWatchlist
                      ? 'bg-gray-700 hover:bg-gray-600'
                      : 'bg-gray-800/80 hover:bg-gray-700'
                  } text-white px-6 py-3 rounded-md font-medium flex items-center transition-colors`}
                  onClick={toggleWatchlist}
                >
                  <Heart className={`w-5 h-5 mr-2 ${isInWatchlist ? 'fill-red-500' : ''}`} />
                  {isInWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
                </button>
              </div>
              
              <div>
                <h3 className="text-white text-xl font-semibold mb-4">Cast</h3>
                <div className="flex overflow-x-auto space-x-4 pb-4">
                  {movie.cast.map(person => (
                    <div key={person.name} className="flex-none w-24">
                      <div className="w-full h-24 rounded-full overflow-hidden mb-2">
                        <img 
                          src={person.imageUrl} 
                          alt={person.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="text-center">
                        <p className="text-white text-sm font-medium">{person.name}</p>
                        <p className="text-gray-400 text-xs">{person.role}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Related Movies Section */}
      {relatedMovies.length > 0 && (
        <div className="bg-gray-900 py-8">
          <MovieSection 
            title="You May Also Like" 
            movies={relatedMovies} 
          />
        </div>
      )}
    </>
  );
};

export default MovieDetails;