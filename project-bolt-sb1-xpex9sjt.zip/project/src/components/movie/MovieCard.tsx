import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, Heart, Clock, Star } from 'lucide-react';
import { Movie } from '../../types/movie';

interface MovieCardProps {
  movie: Movie;
  variant?: 'default' | 'featured' | 'compact';
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, variant = 'default' }) => {
  const [isHovered, setIsHovered] = useState(false);

  if (variant === 'featured') {
    return (
      <div 
        className="relative w-full h-[400px] rounded-xl overflow-hidden group"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="absolute inset-0">
          <img 
            src={movie.backdropUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
          <h3 className="text-white text-2xl font-bold mb-2">{movie.title}</h3>
          <div className="flex items-center space-x-3 mb-3">
            <span className="flex items-center text-yellow-400">
              <Star className="w-4 h-4 mr-1 fill-current" />
              {movie.rating.toFixed(1)}
            </span>
            <span className="text-gray-300">{movie.year}</span>
            <span className="text-gray-300">{movie.duration}</span>
          </div>
          <p className="text-gray-300 mb-4 line-clamp-2">{movie.description}</p>
          <div className="flex space-x-3">
            <Link 
              to={`/movie/${movie.id}`}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md font-medium flex items-center transition-colors"
            >
              <Play className="w-4 h-4 mr-2" />
              Watch
            </Link>
            <button className="bg-gray-800/80 hover:bg-gray-700 text-white p-2 rounded-md flex items-center transition-colors">
              <Heart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <Link 
        to={`/movie/${movie.id}`}
        className="block relative rounded-lg overflow-hidden group"
      >
        <div className="aspect-[2/3] w-full">
          <img 
            src={movie.posterUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
        </div>
        <div className="absolute top-2 right-2">
          <span className="bg-red-600 text-white px-1.5 py-0.5 rounded text-xs font-medium flex items-center">
            <Star className="w-3 h-3 mr-0.5 fill-current" />
            {movie.rating.toFixed(1)}
          </span>
        </div>
        <h3 className="mt-2 text-white font-medium text-sm line-clamp-1">{movie.title}</h3>
        <p className="text-gray-400 text-xs">{movie.year}</p>
      </Link>
    );
  }

  // Default variant
  return (
    <div 
      className="relative rounded-lg overflow-hidden group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-[2/3] w-full bg-gray-800">
        <img 
          src={movie.posterUrl} 
          alt={movie.title} 
          className="w-full h-full object-cover transition-all duration-300 group-hover:scale-110 group-hover:opacity-40"
          loading="lazy"
        />
        
        {/* Hover Overlay */}
        <div className={`absolute inset-0 bg-black/60 flex flex-col justify-center items-center p-4 transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <Link 
            to={`/movie/${movie.id}`}
            className="bg-red-600 hover:bg-red-700 text-white w-12 h-12 rounded-full flex items-center justify-center mb-4 transition-transform duration-300 transform hover:scale-110"
          >
            <Play className="w-6 h-6" />
          </Link>
          
          <div className="flex space-x-2 mb-4">
            <button className="bg-gray-800 hover:bg-gray-700 text-white p-2 rounded-full transition-colors">
              <Heart className="w-5 h-5" />
            </button>
            <button className="bg-gray-800 hover:bg-gray-700 text-white p-2 rounded-full transition-colors">
              <Clock className="w-5 h-5" />
            </button>
          </div>
          
          <div className="text-center">
            <h3 className="text-white font-bold mb-1">{movie.title}</h3>
            <div className="flex items-center justify-center space-x-2 mb-2">
              <span className="text-yellow-400 flex items-center">
                <Star className="w-4 h-4 mr-1 fill-current" />
                {movie.rating.toFixed(1)}
              </span>
              <span className="text-gray-300 text-sm">{movie.year}</span>
            </div>
            <p className="text-gray-300 text-sm line-clamp-3">{movie.genres.join(', ')}</p>
          </div>
        </div>
      </div>
      
      {/* Info (visible when not hovered) */}
      <div className={`p-2 transition-opacity duration-300 ${isHovered ? 'opacity-0' : 'opacity-100'}`}>
        <h3 className="text-white font-medium line-clamp-1">{movie.title}</h3>
        <div className="flex items-center justify-between mt-1">
          <span className="text-gray-400 text-sm">{movie.year}</span>
          <span className="flex items-center text-yellow-400 text-sm">
            <Star className="w-3 h-3 mr-1 fill-current" />
            {movie.rating.toFixed(1)}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;