import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getMovieById } from '../data/movies';
import MovieDetails from '../components/movie/MovieDetails';
import { Movie } from '../types/movie';

const MoviePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // In a real app, this would be an API call
    if (id) {
      const foundMovie = getMovieById(id);
      
      if (foundMovie) {
        setMovie(foundMovie);
        // Update document title
        document.title = `${foundMovie.title} - BDPlix`;
      } else {
        // Movie not found, redirect to 404 or home
        navigate('/');
      }
      
      setLoading(false);
    }
    
    // Cleanup on unmount
    return () => {
      document.title = 'BDPlix - Free Movie Streaming';
    };
  }, [id, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-red-600"></div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 px-4 text-center">
        <h1 className="text-3xl font-bold text-white mb-4">Movie Not Found</h1>
        <p className="text-gray-400 mb-8">The movie you're looking for doesn't exist or has been removed.</p>
        <button 
          onClick={() => navigate('/')}
          className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 min-h-screen">
      <MovieDetails movie={movie} />
    </div>
  );
};

export default MoviePage;