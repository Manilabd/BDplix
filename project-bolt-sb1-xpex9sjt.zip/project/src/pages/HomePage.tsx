import React from 'react';
import HeroSection from '../components/home/HeroSection';
import MovieSection from '../components/home/MovieSection';
import { 
  getFeaturedMovies, 
  getTrendingMovies,
  getMoviesByGenre
} from '../data/movies';

const HomePage: React.FC = () => {
  const featuredMovies = getFeaturedMovies();
  const trendingMovies = getTrendingMovies();
  const actionMovies = getMoviesByGenre('Action');
  const dramaMovies = getMoviesByGenre('Drama');
  const romanceMovies = getMoviesByGenre('Romance');

  return (
    <div className="bg-gray-900 min-h-screen">
      <HeroSection movies={featuredMovies} />
      
      <div className="mt-8">
        <MovieSection 
          title="Featured Movies" 
          movies={featuredMovies.slice(0, 3)} 
          viewAllLink="/featured"
          variant="featured"
        />
        
        <MovieSection 
          title="Trending Now" 
          movies={trendingMovies} 
          viewAllLink="/trending"
        />
        
        <MovieSection 
          title="Action Movies" 
          movies={actionMovies} 
          viewAllLink="/genre/action"
        />
        
        <MovieSection 
          title="Drama" 
          movies={dramaMovies} 
          viewAllLink="/genre/drama"
        />
        
        <MovieSection 
          title="Romance" 
          movies={romanceMovies} 
          viewAllLink="/genre/romance"
          variant="compact"
        />
      </div>
    </div>
  );
};

export default HomePage;