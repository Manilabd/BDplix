import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getMoviesByLanguage } from '../data/movies';
import MovieCard from '../components/movie/MovieCard';
import { Movie, MovieLanguage } from '../types/movie';

const LanguagePage: React.FC = () => {
  const { language } = useParams<{ language: string }>();
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (language) {
      // Capitalize first letter to match our enum format
      const formattedLanguage = language.charAt(0).toUpperCase() + language.slice(1) as MovieLanguage;
      
      // In a real app, this would be an API call
      const languageMovies = getMoviesByLanguage(formattedLanguage);
      setMovies(languageMovies);
      setLoading(false);
      
      // Update document title
      document.title = `${formattedLanguage} Movies - BDPlix`;
    }
    
    // Cleanup on unmount
    return () => {
      document.title = 'BDPlix - Free Movie Streaming';
    };
  }, [language]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-red-600"></div>
      </div>
    );
  }

  const formattedLanguage = language ? language.charAt(0).toUpperCase() + language.slice(1) : '';

  return (
    <div className="bg-gray-900 min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-white text-3xl font-bold mb-2">{formattedLanguage} Movies</h1>
          <p className="text-gray-400">
            Explore our collection of {movies.length} movies in {formattedLanguage}
          </p>
        </div>

        {movies.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {movies.map(movie => (
              <div key={movie.id}>
                <MovieCard movie={movie} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h2 className="text-white text-xl font-medium mb-2">No movies found</h2>
            <p className="text-gray-400">
              We couldn't find any movies in {formattedLanguage}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LanguagePage;