import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import MovieCard from '../components/movie/MovieCard';
import { searchMovies } from '../data/movies';
import { Movie } from '../types/movie';

const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(query);
  const [results, setResults] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (query) {
      setLoading(true);
      // In a real app, this would be an API call with debounce
      setTimeout(() => {
        const searchResults = searchMovies(query);
        setResults(searchResults);
        setLoading(false);
      }, 300);
    }
  }, [query]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery });
    }
  };

  return (
    <div className="bg-gray-900 min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto mb-8">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              placeholder="Search for movies, actors, directors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 text-white rounded-full py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <button 
              type="submit"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded-full text-sm font-medium transition-colors"
            >
              Search
            </button>
          </form>
        </div>

        <div className="mb-8">
          <h1 className="text-white text-3xl font-bold mb-2">
            {query ? `Search Results for "${query}"` : 'Search Movies'}
          </h1>
          {query && (
            <p className="text-gray-400">
              Found {results.length} {results.length === 1 ? 'result' : 'results'}
            </p>
          )}
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-600"></div>
          </div>
        ) : (
          <>
            {results.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                {results.map(movie => (
                  <div key={movie.id}>
                    <MovieCard movie={movie} />
                  </div>
                ))}
              </div>
            ) : (
              query && (
                <div className="text-center py-12">
                  <h2 className="text-white text-xl font-medium mb-2">No results found</h2>
                  <p className="text-gray-400">
                    We couldn't find any movies matching "{query}"
                  </p>
                </div>
              )
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SearchPage;