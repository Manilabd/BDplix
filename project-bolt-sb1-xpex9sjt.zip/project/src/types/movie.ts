export interface Movie {
  id: string;
  title: string;
  description: string;
  posterUrl: string;
  backdropUrl: string;
  year: number;
  duration: string;
  language: string;
  genres: string[];
  rating: number;
  cast: {
    name: string;
    role: string;
    imageUrl: string;
  }[];
  director: string;
  trailerUrl: string;
  isFeatured?: boolean;
  isTrending?: boolean;
}

export type MovieLanguage = 'English' | 'Hindi' | 'Bengali' | 'Spanish' | 'Korean' | 'Japanese' | 'French';

export type MovieGenre = 
  | 'Action' 
  | 'Adventure' 
  | 'Comedy' 
  | 'Drama' 
  | 'Horror' 
  | 'Thriller' 
  | 'Romance' 
  | 'Sci-Fi' 
  | 'Fantasy' 
  | 'Animation'
  | 'Documentary';